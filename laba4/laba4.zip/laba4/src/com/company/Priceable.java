package com.company;

public interface Priceable {
    public int getPrice();
}
